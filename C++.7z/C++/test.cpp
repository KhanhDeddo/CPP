#include<bits/stdc++.h>
using namespace std;
int main(){
    if(true){cout<<"haha";}
    else{}
    return 0;
}